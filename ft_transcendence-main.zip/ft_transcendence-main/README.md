# Transcendence

## How to run

* Recommended OS: Linux
* have docker installed and running
* In your terminal run: ```make```

## Not sure what commands are available?

* type ```make help```
* this will display all available commands of the Makefile